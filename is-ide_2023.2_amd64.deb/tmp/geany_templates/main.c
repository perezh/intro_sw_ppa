/**
 * @file {filename}
 *
 * @brief TODO
 *
 * @author  {developer} <{mail}>
 * @version {date}
 *
**/

#include <stdio.h>

int main (void) {

    return 0;
}
