/**
 * @file {filename}
 *
 * @brief TODO
 *
 * @author  {developer} <{mail}>
 * @version {date}
 *
**/

#ifdef FILENAME_H   //  TODO: Set FILENAME
#define FILENAME_H

void hello (int a);

#endif
