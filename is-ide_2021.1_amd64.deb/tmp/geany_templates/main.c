/*
 * File: {filename}
 *
 * Description:
 *
 * Author:  {developer} <{mail}>
 * Version: {date}
 *
*/

#include <stdio.h>

int main (void) {

    return 0;
}
