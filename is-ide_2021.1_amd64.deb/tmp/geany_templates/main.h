/*
 * File: {filename}
 *
 * Description:
 *
 * Author:  {developer} <{mail}>
 * Version: {date}
 *
*/

#ifdef FILENAME_H   //  TODO: Set FILENAME
#define FILENAME_H

void hello (int a);

#endif
