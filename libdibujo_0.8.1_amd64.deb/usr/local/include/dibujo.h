/**
   @file    dibujo.h
   @brief   Conjunto de módulos para hacer entrada/salida sencilla en C


   @author  Michael Gonzalez <mgh@unican.es>
   @version 0.8
   @date    2021

   Librería dibujo
   Conjunto de módulos para hacer entrada/salida sencilla en C

   Copyright (C)
   Universidad de Cantabria, SPAIN

   Licencia: GPL
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public
   License as published by the Free Software Foundation; either
   version 3 of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   General Public License for more details.

   -----------------------
   Sistema de coordenadas:
   -----------------------

   Las coordenadas se miden en píxeles, siendo el origen de coordenadas la
   esquina superior izquierda de la ventana, el sentido positivo horizontal
   hacia la derecha y el sentido positivo vertical hacia abajo
   <pre>
   0,0
   |----------> X
   |
   |
   |
   Y
   </pre>
   --------------------------------------
   Ejemplo de uso para dibujos estáticos:
   --------------------------------------
   @code

    #include "dibujo.h"

    int main(void){

        // Creamos el dibujo
        crea_ventana ("Prueba de dibujo", 640, 480);

        // Creamos un par de figuras y un texto en el dibujo
        crea_circulo (25, 25, 10, "rojo");
        crea_rectangulo (210, 10, 260, 80, "marron oscuro");
        crea_texto (400, 100, "mi texto", "negro", 40);

        // Pintamos el dibujo y esperamos a que se cierre la ventana
        pinta_y_espera();

        // Destruimos el dibujo
        destruye_ventana();
    }
    @endcode

   -----------------------------
   Ejemplo de un dibujo animado:
   -----------------------------
   @code

    #include "dibujo.h"

    int main (void) {

        // Creamos el dibujo
        crea_ventana ("Prueba de dibujo", 640, 480);

        // Creamos un par de figuras en el dibujo
        figura_t bola = crea_circulo (25, 25, 10, "rojo");
        figura_t triangulo = crea_triangulo (150, 400, 320, 300, 240, 380, "verde");

        bool finalizar;

        do {
            // determinar cuánto hay que moverse
            int delta_x = ...;
            int delta_y = ...;

            // Mover las figuras
            mueve (bola, delta_x, delta_y);
            mueve (triangulo, delta_x, delta_y);

            // Pintamos el dibujo y esperamos a que se cierre la ventana
            finalizar = pinta();

        } while (!finalizar);

        // Destruimos el dibujo
        destruye_ventana();
    }
    @endcode

   ------------------------------------
   Ejemplo de una animación con sprites:
   ------------------------------------
   @code

    #include "dibujo.h"

    #define MAX_COLS    16

    int main (void) {
        int fila = 0;
        int columna = 0;
        bool finalizar;

        // Creamos el dibujo
        crea_ventana ("Sprites", 640, 480);

        // Creamos los sprites e indicamos el tamaño de la matriz (16 columnas x 1 fila)
        figura_t target = crea_sprites (640 / 2, 480 / 2, "resources/target.png", MAX_COLS, 1);

        // Lazo principal
        do {
            // Elegimos el siguiente sprite de la secuencia
            columna++;
            if (columna >= MAX_COLS) {     // Al terminar la secuencia, se reinicia
                columna = 0;
            }

            // Seleccionamos el sprite a dibujar
            selecciona_sprite (target, columna, fila);
            // Pintamos el dibujo y comprobamos si se debe cerrar la ventana
            finalizar = pinta();

        } while (!finalizar);

        // Destruimos el dibujo y liberamos los recursos asociados
        destruye_ventana();
    }
    @endcode

   ----------------------------------------
   Ejemplo de una operación de e/s de datos:
   ----------------------------------------
   @code

    #include <stdbool.h>
    #include "dibujo.h"

    int main (void) {
        int valor;
        bool finalizar;

        // Creamos el dibujo
        crea_ventana ("Prueba de E/S", 640, 480);

        // Creamos unas figuras en el dibujo
        figura_t slider = crea_barra_deslizadora (30, 100, 150, 130);
        figura_t datos = crea_cuadro_datos (200, 100, 230, 130);

        do {
            // Determinar el valor de los controles
            valor = obten_valor_barra_deslizadora (slider);
            establece_valor_cuadro_datos (datos, valor);

            // Pintamos el dibujo y comprobamos si se debe cerrar la ventana
            finalizar = pinta();

        } while (!finalizar);

        // Destruimos el dibujo y liberamos los recursos asociados
        destruye_ventana();

        return 0;
    }
    @endcode

*/

#ifndef DIBUJO_H

#define DIBUJO_H

#include <stdbool.h>
#include <raylib.h>

////////////////////////////////////////////
// Colores definidos:

//  "gris claro",
//  "gris",
//  "gris claro",
//  "amarillo",
//  "dorado",
//  "naranja",
//  "rosa",
//  "rojo",
//  "marron",
//  "verde",
//  "lima",
//  "verde oscuro",
//  "azul celeste",
//  "azul",
//  "azul oscuro",
//  "purpura",
//  "violeta",
//  "purpura oscuro",
//  "beis",
//  "marron",
//  "marron oscuro",
//  "blanco",
//  "negro",
//  "transparente",
//  "magenta",
//  "blanco nieve"
////////////////////////////////////


/**
 * @name Constantes configurables
 * Máximo número de figuras
 * @{
 */

#define MAX_FIGURAS 10000           /**< Número máximo de figuras que pueden dibujarse */

/** @} */

/**
 * @name Constantes de la librería
 * Códigos de error, teclas reconocidas, etc
 * @{
 */
/*
 * Codigos de error
 */

#define CORRECTO 0                          /**< Operación ejecutada correctamente */
#define ERROR_FIGURA_INCORRECTA -1          /**< Figura incorrecta */
#define ERROR_DATOS_INVALIDOS   -2          /**< Error al introducir los datos */
#define ERROR_MAX_FIGURAS_SOBREPASADO -3    /**< Se ha sobrepasado el número máximo de figuras */
#define ERROR_FIGURA_INEXISTENTE -4         /**< La figura indicada no existe en el dibujo */
#define ERROR_FICHERO_NO_ENCONTRADO -5      /**< Fichero no encontrado */

/*
 * Teclas
 */
#define TECLA_ESPACIO   KEY_SPACE           /**< Representa la tecla espacio */
#define TECLA_INTRO     KEY_ENTER           /**< Representa la tecla intro/return */
#define TECLA_ARRIBA    KEY_UP              /**< Representa la tecla de la flecha hacia arriba */
#define TECLA_ABAJO     KEY_DOWN            /**< Representa la tecla de la flecha hacia abajo */
#define TECLA_IZDA      KEY_LEFT            /**< Representa la tecla de la flecha hacia la izquierda */
#define TECLA_DRCHA     KEY_RIGHT           /**< Representa la tecla de la flecha hacia la derecha */

/*
 *  Botones del ratón
 */
#define RATON_BOTON_IZQ  MOUSE_LEFT_BUTTON   /**< Representa el botón izquierdo del ratón */
#define RATON_BOTON_DER  MOUSE_RIGHT_BUTTON  /**< Representa el botón derecho del ratón */
#define RATON_BOTON_CEN  MOUSE_MIDDLE_BUTTON /**< Representa el botón central del ratón */


/** @} */

/**
 * Tipo que representa una figura que se dibuja en la ventana
 */
typedef int figura_t;

/**
 * Tipo que representa un texto (string)
 */
typedef char *texto_t;


/**
 * Crea la ventana
 *
 * @param titulo El título de la ventana
 * @param width Anchura de la ventana en píxeles.
 * @param height Altura de la ventana en píxeles.
 */

void crea_ventana (texto_t titulo, int width, int height);


/**
 * Pinta el dibujo
 *
 * @returns Booleano que indica si se debe destruir la ventana o no
 */

bool pinta (void);


/**
 * Pinta el dibujo y espera hasta que se pulsa ESC o se cierra la ventana
 */

void pinta_y_espera (void);


/**
 * Destruir la ventana
 */
void destruye_ventana (void);


/**
 * Mueve la figura en sentido horizontal y vertical
 *
 * @param fig el identificador de la figura a mover
 * @param delta_x Píxeles a mover en sentido horizontal
 * @param delta_y Píxeles a mover en sentido vertical
 *
 * @returns CORRECTO si todo fue bien o ERROR_FIGURA_INEXISTENTE
 *          si la figura fig no existe
 */

int mueve (figura_t fig, int delta_x, int delta_y);


/**
 * Oculta la figura del dibujo
 *
 * @param fig el identificador de la figura a ocultar
 *
 * @returns CORRECTO si todo fue bien o ERROR_FIGURA_INEXISTENTE
 *          si la figura fig no existe
 */
int oculta (figura_t fig);

/**
 * Muestra una figura que está oculta en el dibujo
 *
 * @param fig el identificador de la figura a ocultar
 *
 * @returns CORRECTO si todo fue bien, ERROR_FIGURA_INEXISTENTE
 *          si la figura fig no existe
 */
int muestra (figura_t fig);

/**
 * Coloca la figura en las coordenadas indicadas
 *
 * @param fig el identificador de la figura a colocar
 * @param c_x: Coordenada x donde se coloca el centro de la figura
 * @param c_y: Coordenada y donde se coloca el centro de la figura
 *
 * @returns CORRECTO si todo fue bien o ERROR_FIGURA_INEXISTENTE
 *          si la figura fig no existe
 */

int coloca (figura_t fig, int c_x, int c_y);


/**
 * Crea una línea entre (x1, y1) y (x2, y2)
 *
 * Si la figura no se puede crear porque se ha alcanzado el máximo
 * número de figuras se retorna ERROR_MAX_FIGURAS_SOBREPASADO
 *
 * @param x1 Coordenada x del punto 1
 * @param y1 Coordenada y del punto 1
 * @param x2 Coordenada x del punto 2
 * @param y2 Coordenada y del punto 2
 * @param color El color de la línea. Ejemplo "rojo", "verde oscuro"
 *              Si el color es incorrecto se pinta en negro
 *
 * @returns El identificador de la figura si se creó con éxito,
 *          ERROR_MAX_FIGURAS_SOBREPASADO en caso de error
 */

figura_t crea_linea (int x1, int y1, int x2, int y2, texto_t color);


/**
 * Crea un circulo centrado en (xcentro, ycentro) y del radio indicado
 *
 * Si la figura no se puede crear porque se ha alcanzado el máximo
 * número de figuras se retorna ERROR_MAX_FIGURAS_SOBREPASADO
 *
 * @param xcentro Coordenada x del centro
 * @param ycentro Coordenada y del centro
 * @param radio radio del círculo
 * @param color El color de la línea. Ejemplo "rojo", "verde oscuro"
 *              Si el color es incorrecto se pinta en negro
 *
 * @returns El identificador de la figura si se creó con éxito,
 *          ERROR_MAX_FIGURAS_SOBREPASADO en caso de error
 */

figura_t crea_circulo (int xcentro, int ycentro,
                       int radio, texto_t color);



/**
 * Crea un rectángulo de esquinas en (xmin, ymin) y (xmax, ymax)
 *
 * Si la figura no se puede crear porque se ha alcanzado el máximo
 * número de figuras se retorna ERROR_MAX_FIGURAS_SOBREPASADO
 *
 * @param xmin Coordenada x de la esquina superior izquierda
 * @param ymin Coordenada y de la esquina superior izquierda
 * @param xmax Coordenada x de la esquina inferior derecha
 * @param ymax Coordenada y de la esquina inferior derecha
 * @param color El color de la línea. Ejemplo "rojo", "verde oscuro"
 *              Si el color es incorrecto se pinta en negro
 *
 * @returns El identificador de la figura si se creó con éxito,
 *          ERROR_MAX_FIGURAS_SOBREPASADO en caso de error
 */

figura_t crea_rectangulo (int xmin, int ymin, int xmax,
                          int ymax, texto_t color);


/**
 * Crea un triangulo de vértices en (x1, y1), (x2, y2) y (x3, y3).
 *
 * Si la figura no se puede crear porque se ha alcanzado el máximo
 * número de figuras se retorna ERROR_MAX_FIGURAS_SOBREPASADO
 *
 * @param x1 Coordenada x del primer vértice
 * @param y1 Coordenada y del primer vértice
 * @param x2 Coordenada x del segundo vértice
 * @param y2 Coordenada y del segundo vértice
 * @param x3 Coordenada x del tercer vértice
 * @param y3 Coordenada y del tercer vértice
 * @param color El color de la línea. Ejemplo "rojo", "verde oscuro"
 *              Si el color es incorrecto se pinta en negro
 *
 * @returns El identificador de la figura si se creó con éxito,
 *          ERROR_MAX_FIGURAS_SOBREPASADO en caso de error
 */

figura_t crea_triangulo (int x1, int y1, int x2, int y2,
                         int x3, int y3, texto_t color);


/**
 * Crea un poligono abierto o cerrado. Las coordenadas del polígono
 * se definen en dos listas de coordenadas x y y, que deben ser del
 * mismo tamaño
 *
 * Si la figura no se puede crear porque se ha alcanzado el máximo
 * número de figuras se retorna ERROR_MAX_FIGURAS_SOBREPASADO
 *
 * @param puntos_x Una lista de las coordenadas x de los puntos del
 *                 polígono, de tamaño size
 * @param puntos_y Una lista de las coordenadas y de los puntos del
 *                 polígono, de tamaño size
 * @param size El tamaño de las listas de puntos
 * @param color El color del polígono. Ejemplo "rojo", "verde oscuro"
 *              Si el color es incorrecto se pinta en negro
 * @param abierto Determina si el polígono es abierto o cerrado
 *
 * @returns El identificador de la figura si se creó con éxito,
 *          ERROR_MAX_FIGURAS_SOBREPASADO en caso de error
 *
 */

figura_t crea_poligono (int puntos_x[], int puntos_y[], int size,
                        texto_t color, bool abierto);


/**
 * Crea una imagen obtenida a partir de un archivo .png para dibujar
 * en la posición indicada
 *
 * Si la figura no se puede crear porque se ha alcanzado el máximo
 * número de figuras se retorna ERROR_MAX_FIGURAS_SOBREPASADO
 *
 * @param pos_x Coordenada x del centro de la imagen
 * @param pos_y Coordenada y del centro de la imagen
 * @param nombre_fichero El nombre del fichero, incluyendo la extensión
 *
 * @returns El identificador de la figura si se creó con éxito,
 *          ERROR_MAX_FIGURAS_SOBREPASADO o ERROR_FICHERO_NO_ENCONTRADO en caso de error
 *
 */

figura_t crea_imagen (int pos_x, int pos_y, texto_t nombre_fichero);


/**
 * Crea un texto en la posición indicada
 *
 * Si la figura no se puede crear porque se ha alcanzado el máximo
 * número de figuras se retorna ERROR_MAX_FIGURAS_SOBREPASADO
 *
 * @param pos_x Coordenada x del centro del texto
 * @param pos_y Coordenada y del centro del texto
 * @param el_texto El texto a representar
 * @param color El color del texto. Ejemplo "rojo", "verde oscuro"
 *              Si el color es incorrecto se pinta en negro
 * @param size El tamaño de la letra
 *
 * @returns El identificador de la figura si se creó con éxito,
 *          ERROR_MAX_FIGURAS_SOBREPASADO en caso de error
 *
 */
figura_t crea_texto (int pos_x, int pos_y, texto_t el_texto,
                     texto_t color, int size);

/**
 * Modifica el texto con el identificador de figura indicado
 *
 * @param fig el identificador de la figura del texto
 * @param texto_nuevo El texto a representar
 *
 * @returns CORRECTO si todo fue bien, ERROR_FIGURA_INEXISTENTE si la figura fig no existe o
 *          ERROR_FIGURA_INCORRECTA si la figura no es del tipo adecuado
 */
int modifica_texto (figura_t fig, texto_t texto_nuevo);

/**
 * Crea una barra deslizadora con datos representables entre 0 y 100
 *
 * Si la figura no se puede crear porque se ha alcanzado el máximo
 * número de figuras se retorna ERROR_MAX_FIGURAS_SOBREPASADO
 *
 * @param xmin Coordenada x de la esquina superior izquierda
 * @param ymin Coordenada y de la esquina superior izquierda
 * @param xmax Coordenada x de la esquina inferior derecha
 * @param ymax Coordenada y de la esquina inferior derecha
 *
 * @returns El identificador de la figura si se creó con éxito,
 *          ERROR_MAX_FIGURAS_SOBREPASADO en caso de error
 *
 */
figura_t crea_barra_deslizadora (int xmin, int ymin, int xmax, int ymax);

/**
 * Obtiene el valor actual de la barra deslizadora
 *
 *
 * @param fig el identificador de la figura de la barra deslizadora
 *
 * @returns El valor almacenado en la barra si todo fue bien, ERROR_FIGURA_INEXISTENTE
 *          si la figura fig no existe o ERROR_FIGURA_INCORRECTA si
 *          la figura no es del tipo adecuado
 *
 */

float obten_valor_barra_deslizadora (figura_t fig);

/**
 * Crea un conjunto de sprites obtenidos a partir de un archivo .png para dibujar
 * en la posición indicada. Por defecto, selecciona el primer sprite para mostrar (esto es,
 * el que se encuentra en la primera fila y primera columna)
 *
 * Si la figura no se puede crear porque se ha alcanzado el máximo
 * número de figuras se retorna ERROR_MAX_FIGURAS_SOBREPASADO
 *
 * @param pos_x Coordenada x del centro del sprite a dibujar
 * @param pos_y Coordenada y del centro del sprite a dibujar
 * @param nombre_fichero La ruta al fichero, incluyendo la extensión
 * @param cols Número de columnas del sprite
 * @param rows Número de filas del sprite
 *
 * @returns El identificador de la figura si se creó con éxito,
 *          ERROR_MAX_FIGURAS_SOBREPASADO o ERROR_FICHERO_NO_ENCONTRADO en caso de error
 *
 */

figura_t crea_sprites (int pos_x, int pos_y, texto_t nombre_fichero, int cols, int rows);

/**
 * Selecciona un sprite de la figura
 *
 *
 * @param fig el identificador de la figura del sprite
 * @param col Número de columna a seleccionar en el sprite, empezando en 0
 * @param row Número de fila a seleccionar en el sprite, empezando en 0
 *
 * @returns CORRECTO si todo fue bien, ERROR_FIGURA_INEXISTENTE
 *          si la figura fig no existe o ERROR_FIGURA_INCORRECTA si
 *          la figura no es del tipo sprite o ERROR_DATOS_INVALIDOS si
 *          la columna o la fila no están dentro del rango permitido
 *
 */

int selecciona_sprite (figura_t fig, int col, int row);

/**
 * Aplica simetria respecto al eje vertical al sprite
 *
 *
 * @param fig el identificador de la figura del sprite
 *
 * @returns CORRECTO si todo fue bien, ERROR_FIGURA_INEXISTENTE
 *          si la figura fig no existe o ERROR_FIGURA_INCORRECTA si
 *          la figura no es del tipo sprite
 *
 */
int aplica_simetria_eje_vertical_sprite (figura_t fig);

/**
 * Determina si se ha pulsado (y liberado) la tecla al menos una vez
 * @param tecla La tecla a comprobar
 * @returns verdadero si la tecla se ha pulsado (y liberado), falso en caso contrario
 *
 */
bool tecla_pulsada (int tecla);

/**
 * Determina la coordenada x del puntero del ratón respecto al origen de coordenadas
 * de la ventana gráfica. Esta función considera la pantalla entera, no solo la ventana gráfica.
 * @returns la coordenada x del puntero
 *
 */
int raton_coordx (void);

/**
 * Determina la coordenada y del puntero del ratón respecto al origen de coordenadas
 * de la ventana gráfica. Esta función considera la pantalla entera, no solo la ventana gráfica.
 * @returns la coordenada y del puntero
 *
 */
int raton_coordy (void);

/**
 * Determina si se ha pulsado (y liberado) el botón del ratón al menos una vez
 * @param boton El botón a comprobar
 * @returns verdadero si el botón se ha pulsado (y liberado), falso en caso contrario
 *
 */
bool raton_boton_pulsado (int boton);

/**
 * Crea un cuadro de datos para mostrar valores enteros.
 *
 * Este cuadro no es editable a través de la interfaz gráfica.
 *
 * Si la figura no se puede crear porque se ha alcanzado el máximo
 * número de figuras se retorna ERROR_MAX_FIGURAS_SOBREPASADO
 *
 * @param xmin Coordenada x de la esquina superior izquierda del cuadro de valores
 * @param ymin Coordenada y de la esquina superior izquierda del cuadro de valores
 * @param xmax Coordenada x de la esquina inferior derecha del cuadro de valores
 * @param ymax Coordenada y de la esquina inferior derecha del cuadro de valores
 *
 * @returns El identificador de la figura si se creó con éxito,
 *          ERROR_MAX_FIGURAS_SOBREPASADO en caso de error
 */
figura_t crea_cuadro_datos (int xmin, int ymin, int xmax, int ymax);

/**
 * Establece el valor del cuadro de datos
 *
 * @param fig el identificador de la figura del cuadro de datos
 * @param valor el valor a mostrar en el cuadro de datos
 *
 * @returns CORRECTO si todo fue bien, ERROR_FIGURA_INEXISTENTE si la figura fig no existe o
 *          ERROR_FIGURA_INCORRECTA si la figura no es del tipo adecuado
 */
int establece_valor_cuadro_datos (figura_t fig, float valor);

/**
 * Crea un cuadro de colores seleccionables.
 *
 * Si la figura no se puede crear porque se ha alcanzado el máximo
 * número de figuras se retorna ERROR_MAX_FIGURAS_SOBREPASADO
 *
 * @param xmin Coordenada x de la esquina superior izquierda
 * @param ymin Coordenada y de la esquina superior izquierda
 * @param xmax Coordenada x de la esquina inferior derecha
 * @param ymax Coordenada y de la esquina inferior derecha
 *
 * @returns El identificador de la figura si se creó con éxito,
 *          ERROR_MAX_FIGURAS_SOBREPASADO en caso de error
 */
figura_t crea_cuadro_seleccion_colores (int xmin, int ymin, int xmax, int ymax);

/**
 * Obtiene un componente del color seleccionado en el cuadro de colores
 *
 * @param fig el identificador de la figura del cuadro de colores
 * @param componente el componente del color. Valores posibles: 'R', 'G', 'B'
 *
 * @returns El valor del componente indicado para el color elegido si todo fue bien,
 *          ERROR_FIGURA_INEXISTENTE si la figura fig no existe,
 *          ERROR_FIGURA_INCORRECTA si la figura no es del tipo adecuado o
 *          ERROR_DATOS_INVALIDOS si el componente indicado no se corresponde con 'R', 'G' o 'B'
 *
 */
int obten_componente_cuadro_colores (figura_t fig, char componente);

/**
 * Habilita los mensajes de log de la librería
 */
void activa_log (void);

#endif // DIBUJO_H
